/**
 * 
 */
/**
 * @author jairg
 *
 */
module bytebank_encapsulado {
}