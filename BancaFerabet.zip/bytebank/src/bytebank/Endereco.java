package bytebank;

public class Endereco {
	String cep;
	String cidade_estado;
	String rua;
	int numerodaCasa;
	public Endereco(String cep, String cidade_estado, String rua, int numerodaCasa) {
		super();
		this.cep = cep;
		this.cidade_estado = cidade_estado;
		this.rua = rua;
		this.numerodaCasa = numerodaCasa;
	}
	
}
