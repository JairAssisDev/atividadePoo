package bytebank;

public class TestaSacaNegativo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Conta conta = new Conta();
		conta.depositar(100);
		System.out.println(conta.sacar(101));
		
		conta.sacar(101);
		
		System.out.println(conta.getSaldo());
	}

}
