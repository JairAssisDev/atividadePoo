package caracteres;

public class TestaCaracteres {
	
	public static void main(String[]args) {
		//guarda um unico caractere e só pode ser quardado por '' ou por numero mais cada numero vai ser um sinbulo especifico
		char sinbuli = 5322;
		System.out.println(sinbuli);
		char letra = 's';
		System.out.println(letra);
		
		char valor = 65;
		System.out.println(valor);
		
		valor = (char) (valor+1);
		System.out.println(valor);
		
		String palavra="JairAssis";
		System.out.println(palavra );
		
		palavra=palavra+"Dev";
		System.out.println(palavra);
		

}
	}
