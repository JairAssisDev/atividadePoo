package lacodeRepeticao;

public class Programa {
	public static void main(String[] args) {
		int contador=1;
		while(contador<=10) {
			System.out.println(contador);
			contador++;
		}
	}
}
