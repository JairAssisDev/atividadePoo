package lacodeRepeticao;

public class lacoFor {
	public static void main(String[] args) {
		for(int contador=1; contador<=10;contador++) {
			System.out.println(contador);
		}
	}
}
